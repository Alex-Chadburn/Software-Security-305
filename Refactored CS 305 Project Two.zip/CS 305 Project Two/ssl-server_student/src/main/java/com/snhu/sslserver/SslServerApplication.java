package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}
@RestController
class ServerController{
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello World Check Sum!";
    	 try { //MessageDigest can throw errors, keep it inside a try statement.
             MessageDigest md = MessageDigest.getInstance("SHA-256"); // We are using SHA-256 as it is highly collision resistant
             byte[] hashBytes = md.digest(data.getBytes(StandardCharsets.UTF_8)); // we get an array of bytes to convert to hexadecimal
             String checksum = bytesToHex(hashBytes); //Call function for formatting

             return "<p>Data: " + data + "</p><p>SHA-256 : Checksum Value:" + checksum; //Recreated shown formatting
         } catch (NoSuchAlgorithmException e) { // Remember we have to address the case in which there is an exception
             return "<p>Error: SHA-256 algorithm not found.</p>";
         }
     }

     // Helper method to convert bytes to hex format
     private String bytesToHex(byte[] bytes) { //takes in an array of bytes
         BigInteger number = new BigInteger(1, bytes); // Using an unsigned BigInteger to correctly convert bytes to a hexadecimal string
         return String.format("%064x", number); //formatting the bytes into 64 character long hexadecimal number
     }
 }